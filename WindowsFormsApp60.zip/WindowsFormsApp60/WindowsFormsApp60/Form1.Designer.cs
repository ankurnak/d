﻿
namespace WindowsFormsApp60
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.textBoxNumerator1 = new System.Windows.Forms.TextBox();
            this.textBoxDenominator1 = new System.Windows.Forms.TextBox();
            this.textBoxNumerator2 = new System.Windows.Forms.TextBox();
            this.textBoxDenominator2 = new System.Windows.Forms.TextBox();
            this.labelResult = new System.Windows.Forms.TextBox();
            this.textBoxPower = new System.Windows.Forms.TextBox();
            this.labelFraction1 = new System.Windows.Forms.TextBox();
            this.labelFraction2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(27, 303);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 25);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(27, 348);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 25);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(146, 303);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 25);
            this.button3.TabIndex = 2;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(146, 348);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 25);
            this.button4.TabIndex = 3;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(278, 303);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(82, 25);
            this.button5.TabIndex = 4;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(278, 348);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(82, 25);
            this.button6.TabIndex = 5;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(406, 303);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(82, 25);
            this.button7.TabIndex = 6;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(406, 348);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(82, 25);
            this.button8.TabIndex = 7;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(525, 303);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 25);
            this.button9.TabIndex = 8;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(525, 348);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(82, 25);
            this.button10.TabIndex = 9;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(648, 303);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(82, 25);
            this.button11.TabIndex = 10;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(648, 348);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(82, 25);
            this.button12.TabIndex = 11;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(27, 400);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(82, 25);
            this.button13.TabIndex = 12;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(146, 400);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(82, 25);
            this.button14.TabIndex = 13;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // textBoxNumerator1
            // 
            this.textBoxNumerator1.Location = new System.Drawing.Point(17, 8);
            this.textBoxNumerator1.Name = "textBoxNumerator1";
            this.textBoxNumerator1.Size = new System.Drawing.Size(91, 22);
            this.textBoxNumerator1.TabIndex = 14;
            // 
            // textBoxDenominator1
            // 
            this.textBoxDenominator1.Location = new System.Drawing.Point(18, 52);
            this.textBoxDenominator1.Name = "textBoxDenominator1";
            this.textBoxDenominator1.Size = new System.Drawing.Size(91, 22);
            this.textBoxDenominator1.TabIndex = 15;
            // 
            // textBoxNumerator2
            // 
            this.textBoxNumerator2.Location = new System.Drawing.Point(238, 8);
            this.textBoxNumerator2.Name = "textBoxNumerator2";
            this.textBoxNumerator2.Size = new System.Drawing.Size(91, 22);
            this.textBoxNumerator2.TabIndex = 16;
            // 
            // textBoxDenominator2
            // 
            this.textBoxDenominator2.Location = new System.Drawing.Point(238, 52);
            this.textBoxDenominator2.Name = "textBoxDenominator2";
            this.textBoxDenominator2.Size = new System.Drawing.Size(91, 22);
            this.textBoxDenominator2.TabIndex = 17;
            // 
            // labelResult
            // 
            this.labelResult.Location = new System.Drawing.Point(435, 8);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(91, 22);
            this.labelResult.TabIndex = 18;
            // 
            // textBoxPower
            // 
            this.textBoxPower.Location = new System.Drawing.Point(435, 52);
            this.textBoxPower.Name = "textBoxPower";
            this.textBoxPower.Size = new System.Drawing.Size(91, 22);
            this.textBoxPower.TabIndex = 19;
            // 
            // labelFraction1
            // 
            this.labelFraction1.Location = new System.Drawing.Point(602, 8);
            this.labelFraction1.Name = "labelFraction1";
            this.labelFraction1.Size = new System.Drawing.Size(91, 22);
            this.labelFraction1.TabIndex = 20;
            // 
            // labelFraction2
            // 
            this.labelFraction2.Location = new System.Drawing.Point(602, 52);
            this.labelFraction2.Name = "labelFraction2";
            this.labelFraction2.Size = new System.Drawing.Size(91, 22);
            this.labelFraction2.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelFraction2);
            this.Controls.Add(this.labelFraction1);
            this.Controls.Add(this.textBoxPower);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.textBoxDenominator2);
            this.Controls.Add(this.textBoxNumerator2);
            this.Controls.Add(this.textBoxDenominator1);
            this.Controls.Add(this.textBoxNumerator1);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox textBoxNumerator1;
        private System.Windows.Forms.TextBox textBoxDenominator1;
        private System.Windows.Forms.TextBox textBoxNumerator2;
        private System.Windows.Forms.TextBox textBoxDenominator2;
        private System.Windows.Forms.TextBox labelResult;
        private System.Windows.Forms.TextBox textBoxPower;
        private System.Windows.Forms.TextBox labelFraction1;
        private System.Windows.Forms.TextBox labelFraction2;
    }
}

